package com.mz.mzapp.vo;

import lombok.*;

import java.util.Date;

@Data
public class TagVO{
    private int t_no;
    private String t_name;
    private String t_type;

}