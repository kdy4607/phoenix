package com.mz.mzapp.mapper;

import com.mz.mzapp.vo.MovieVO;
import com.mz.mzapp.vo.TagVO;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface MovieMapper {

    // 전체 조회 + 태그 리스트 포함
    @Select("SELECT * FROM movie_test")
    @Results({
            @Result(property = "m_no", column = "m_no"),
            @Result(property = "m_title", column = "m_title"),
            @Result(property = "m_description", column = "m_description"),
            @Result(property = "m_poster", column = "m_poster"),
            @Result(property = "m_tagList", column = "m_no",
                    many = @Many(select = "getTagsByMovieNo"))
    })
    List<MovieVO> selectAllMovie();

    // 단일 영화 조회
    @Select("SELECT * FROM movie_test WHERE m_no = #{num}")
    MovieVO selectMovie(int num);

    // 영화 삭제
    @Delete("DELETE FROM movie_test WHERE m_no = #{num}")
    int deleteMovie(int num);

    // 영화 수정
    @Update("""
        UPDATE movie_test
        SET m_title = #{m_title},
            m_description = #{m_description},
            m_poster = #{m_poster}
        WHERE m_no = #{m_no}
        """)
    int updateMovie(MovieVO movie);

    // 영화 등록
    @Insert("""
        INSERT INTO movie_test (m_no, m_title, m_description, m_poster)
        VALUES (movie_test_seq.nextval, #{m_title}, #{m_description}, #{m_poster})
        """)
    int insertMovie(MovieVO movieVO);

    // 영화 + 태그 JOIN (현재는 안 씀, 참고용)
    @Select("""
        SELECT
            m.m_no,
            m.m_title,
            m.m_description,
            m.m_poster,
            t.t_no,
            t.t_name,
            t.t_type
        FROM movie_test m
        LEFT JOIN movie_tag_test mt ON m.m_no = mt.movie_no
        LEFT JOIN tag_test t ON mt.tag_no = t.t_no
        ORDER BY m.m_no
        """)
    @Results(id = "movieWithTags", value = {
            @Result(column = "m_no", property = "m_no", id = true),
            @Result(column = "m_title", property = "m_title"),
            @Result(column = "m_description", property = "m_description"),
            @Result(column = "m_poster", property = "m_poster"),
            @Result(property = "m_tagList", column = "m_no",
                    many = @Many(select = "getTagsByMovieNo"))
    })
    List<MovieVO> selectMovieWithTags();

    // 특정 영화의 태그 목록 조회
    @Select("""
        SELECT t.t_no, t.t_name, t.t_type
        FROM movie_tag_test mt
        JOIN tag_test t ON mt.tag_no = t.t_no
        WHERE mt.movie_no = #{m_no}
        """)
    List<TagVO> getTagsByMovieNo(int m_no);
}
