package com.mz.mzapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HC {

    @GetMapping("/czcz")
    public String czcz(){
        return "czcz";
    }
}
