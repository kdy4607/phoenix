package com.mz.mzapp.controller;

// servlet -> url 파일을 다수로 운용.
// url 매핑 / 흐름 제어

import com.mz.mzapp.mapper.TagMapper;
import com.mz.mzapp.service.MovieService;
import com.mz.mzapp.vo.MovieVO;
import com.mz.mzapp.vo.TagVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MovieC {

    @Autowired          // 의존성 주입   DI
    private MovieService movieService;
    @Autowired
    private TagMapper tagMapper;


    @GetMapping("/movie-all")
    public String movieAll(Model model){
        model.addAttribute("movies",  movieService.getAllmovie() );
        List<TagVO> tagList = tagMapper.selectAllTag();
        model.addAttribute("tagList", tagList);

        return "movie/movie";
    }
    @GetMapping("/movie-detail")
    public String movieDetail(@RequestParam("no") int num, Model model){
        System.out.println("movie-detail -----");
        model.addAttribute("movie", movieService.detailMovie(num));
        return "movie/detail";
    }

    @PostMapping("/movie-add")
    public String movieAdd(MovieVO movieVO){
        System.out.println("movie-add -----");
        // 값 한번에 받기 => 객체
        System.out.println(movieVO);
        movieService.addMovie(movieVO);
        return "redirect:/movie-all";
    }

    @GetMapping("/movie-del")
    public String movieDel(@RequestParam("no") int num){
        System.out.println("movie-del -----");
        movieService.delMovie(num);
        return "redirect:/movie-all";
    }



    @GetMapping("/movie-modi")
    public String movieUpdate(@RequestParam int no, Model model){
        System.out.println(no);
        System.out.println("movie-update -----");
   model.addAttribute("movie",   movieService.detailMovie(no));
        return "movie/modi";
    }
    @PostMapping("/movie-modi")
    public String movieUpdate(MovieVO movieVO){
        System.out.println("movie-update -----");
        System.out.println(movieVO);
        movieService.modifyMovie(movieVO);
        return "redirect:/movie-detail?no=" + movieVO.getM_no();
    }



}
