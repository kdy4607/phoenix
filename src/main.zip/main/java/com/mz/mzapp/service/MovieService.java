package com.mz.mzapp.service;

import com.mz.mzapp.mapper.MovieMapper;
import com.mz.mzapp.vo.MovieVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {

    @Autowired
    private MovieMapper movieMapper;


    // 전체조회
    public List<MovieVO> getAllmovie() {
        List<MovieVO> movies = movieMapper.selectAllMovie();
        System.out.println(movies);
        return movies;
    }

    // 상세조회
    public MovieVO detailMovie(int num) {
        MovieVO movie = movieMapper.selectMovie(num);
        System.out.println(movie);
        return movie;
    }



    // 등록
    public void addMovie(MovieVO movieVO) {
        if (movieMapper.insertMovie(movieVO) == 1) {
            System.out.println("add movie success");
        }

    }

    public void delMovie(int num) {
        if (movieMapper.deleteMovie(num) == 1) {
            System.out.println("delete movie success");
        }
    }

    public void modifyMovie(MovieVO movie) {
        if (movieMapper.updateMovie(movie) == 1) {
            System.out.println("update movie success");
        }
    }


}
